Readme File
September 2006
This package contains HSQLDB 1.8.0.7

HSQLDB is a relational database engine and a set of tools written in Java.
The file index.html in this directory contains the list of directories with their contents.
Documentation and license information can be found in the /doc directory.
Project home page: http://hsqldb.org
Please check the site periodically for updated versions.
